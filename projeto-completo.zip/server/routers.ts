import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { barberProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createAppointment, createBarbershop, getBarbershopForUser, getBarbershopNameForUser, getOwnedBarbershop, listAppointmentsForShop, listAppointmentsForUser, listBarbershopClients, listBarbershops, markUserInactive, renameOwnedBarbershop, selectBarbershop, touchUserActivity, updateAppointmentStatus, updateCustomerName, updateCustomerProfile, updateUserAvatar, updateUserBackground, updateUserPreferences } from "./db";
import { storagePut } from "./storage";

const serviceSchema = z.enum(["degrade", "pigmentacao", "barba", "pe-cabelo"]);
const bookingFields = {
  service: serviceSchema,
  appointmentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  appointmentTime: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/),
  note: z.string().trim().max(500).optional(),
};
const profileSchema = z.object({
  firstName: z.string().trim().min(1, "Informe seu nome.").max(80),
  lastName: z.string().trim().min(1, "Informe seu sobrenome.").max(80),
  birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Informe uma data válida."),
  phone: z.string().trim().min(8, "Informe seu telefone.").max(32),
});
const musicTrackSchema = z.enum(["none", "pixabay-dark-beat", "corte-em-dia", "fade-tranquilo", "navalha-de-ouro"]);
const backgroundStyleSchema = z.enum(["default", "scissors", "clippers", "custom"]);
const shopNameSchema = z.string().trim().min(2, "Digite um nome com pelo menos 2 caracteres.").max(80)
  .regex(/^[\p{L}\p{M}0-9][\p{L}\p{M}0-9 &'.,-]*$/u, "Use letras, números, espaços e pontuação simples.");
const uploadSchema = z.object({
  target: z.enum(["avatar", "background"]),
  mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]),
  data: z.string().min(16).max(7_000_000),
});

function validImageBytes(buffer: Buffer, mimeType: string) {
  if (mimeType === "image/jpeg") return buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  if (mimeType === "image/png") return buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  return mimeType === "image/webp" && buffer.length >= 12 && buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP";
}

async function requireMyShop(user: Parameters<typeof getBarbershopForUser>[0]) {
  const shop = await getBarbershopForUser(user);
  if (!shop || (user.role !== "admin" && shop.ownerUserId !== user.id)) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Crie uma barbearia antes de gerir horários e clientes." });
  }
  return shop;
}

function assertFutureSlot(date: string, time: string) {
  const parsedDate = new Date(`${date}T00:00:00.000Z`);
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  const today = `${values.year}-${values.month}-${values.day}`;
  const currentTime = `${values.hour}:${values.minute}`;
  if (Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== date || date < today || (date === today && time <= currentTime)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Escolha um horário futuro." });
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      if (ctx.user) await touchUserActivity(ctx.user.id);
      return ctx.user;
    }),
    saveCustomerProfile: protectedProcedure.input(profileSchema).mutation(async ({ ctx, input }) => {
      const parsed = new Date(`${input.birthDate}T12:00:00`);
      if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== input.birthDate || parsed > new Date()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Confira a data de nascimento informada." });
      }
      await updateCustomerProfile(ctx.user.id, input);
      return { success: true };
    }),
    updateMyName: protectedProcedure.input(z.object({
      firstName: z.string().trim().min(1, "Informe seu nome.").max(80),
      lastName: z.string().trim().min(1, "Informe seu sobrenome.").max(80),
    })).mutation(async ({ ctx, input }) => {
      await updateCustomerName(ctx.user.id, input);
      return { success: true };
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      if (ctx.user) await markUserInactive(ctx.user.id);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  shops: router({
    list: publicProcedure.query(() => listBarbershops()),
    mine: barberProcedure.query(({ ctx }) => getBarbershopForUser(ctx.user)),
    create: barberProcedure.input(z.object({ name: shopNameSchema })).mutation(async ({ ctx, input }) => {
      const existing = await getOwnedBarbershop(ctx.user.id);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Esta conta já tem uma barbearia." });
      const shop = await createBarbershop(ctx.user.id, input.name);
      if (!shop) throw new TRPCError({ code: "CONFLICT", message: "Esta conta já tem uma barbearia." });
      return { id: shop.id, name: shop.name };
    }),
    select: protectedProcedure.input(z.object({ barbershopId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "user") throw new TRPCError({ code: "FORBIDDEN", message: "Somente clientes podem escolher uma barbearia." });
      if (!ctx.user.firstName?.trim() || !ctx.user.lastName?.trim() || !ctx.user.birthDate || !ctx.user.phone?.trim()) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Complete seu cadastro de cliente antes de escolher uma barbearia." });
      }
      const selected = await selectBarbershop(ctx.user.id, input.barbershopId);
      if (!selected) throw new TRPCError({ code: "NOT_FOUND", message: "Essa barbearia não está disponível." });
      return { success: true };
    }),
    clients: barberProcedure.query(async ({ ctx }) => {
      const shop = await requireMyShop(ctx.user);
      const clients = await listBarbershopClients(shop.id);
      const activeAfter = Date.now() - 5 * 60 * 1000;
      return clients.map(client => ({ ...client, connected: client.lastActiveAt !== null && client.lastActiveAt.getTime() >= activeAfter }));
    }),
  }),
  appointments: router({
    request: protectedProcedure.input(z.object(bookingFields)).mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "user") throw new TRPCError({ code: "FORBIDDEN", message: "Entre como cliente para pedir um horário." });
      assertFutureSlot(input.appointmentDate, input.appointmentTime);
      const firstName = ctx.user.firstName?.trim();
      const lastName = ctx.user.lastName?.trim();
      const customerPhone = ctx.user.phone?.trim();
      if (!firstName || !lastName || !customerPhone || !ctx.user.birthDate) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Complete seu cadastro de cliente antes de pedir um horário." });
      }
      const shop = await getBarbershopForUser(ctx.user);
      if (!shop) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Escolha uma barbearia antes de pedir um horário." });
      const ok = await createAppointment({
        ...input,
        barbershopId: shop.id,
        customerName: `${firstName} ${lastName}`,
        customerPhone,
        customerUserId: ctx.user.id,
        createdByUserId: ctx.user.id,
        note: input.note ?? null,
        status: "pending",
      });
      if (!ok) throw new TRPCError({ code: "CONFLICT", message: "Esse horário já está solicitado nesta barbearia. Escolha outro horário." });
      return { success: true };
    }),
    mine: protectedProcedure.query(({ ctx }) => listAppointmentsForUser(ctx.user.id)),
    list: barberProcedure.query(async ({ ctx }) => {
      const shop = await requireMyShop(ctx.user);
      return listAppointmentsForShop(shop.id);
    }),
    createForCustomer: barberProcedure.input(z.object({ ...bookingFields, customerName: z.string().trim().min(2).max(160), customerPhone: z.string().trim().min(8).max(32) })).mutation(async ({ ctx, input }) => {
      const shop = await requireMyShop(ctx.user);
      assertFutureSlot(input.appointmentDate, input.appointmentTime);
      const ok = await createAppointment({
        ...input,
        barbershopId: shop.id,
        customerUserId: null,
        createdByUserId: ctx.user.id,
        note: input.note ?? null,
        status: "confirmed",
      });
      if (!ok) throw new TRPCError({ code: "CONFLICT", message: "Esse horário já está ocupado nesta barbearia. Escolha outro." });
      return { success: true };
    }),
    updateStatus: barberProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["confirmed", "cancelled"]) })).mutation(async ({ ctx, input }) => {
      const shop = await requireMyShop(ctx.user);
      const found = await updateAppointmentStatus(input.id, shop.id, input.status);
      if (!found) throw new TRPCError({ code: "NOT_FOUND", message: "Esse horário não pertence à sua barbearia." });
      return { success: true };
    }),
  }),
  settings: router({
    businessName: protectedProcedure.query(({ ctx }) => getBarbershopNameForUser(ctx.user)),
    saveBusinessName: barberProcedure.input(z.object({ name: shopNameSchema })).mutation(async ({ ctx, input }) => {
      await requireMyShop(ctx.user);
      const saved = await renameOwnedBarbershop(ctx.user.id, input.name);
      if (!saved) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Crie uma barbearia antes de alterar o nome." });
      return { name: input.name };
    }),
    save: protectedProcedure.input(z.object({ musicTrack: musicTrackSchema, backgroundStyle: backgroundStyleSchema })).mutation(async ({ ctx, input }) => {
      if (input.backgroundStyle === "custom" && !ctx.user.backgroundImage) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Envie uma imagem antes de aplicar o fundo da galeria." });
      }
      await updateUserPreferences(ctx.user.id, input);
      return { success: true };
    }),
    uploadImage: protectedProcedure.input(uploadSchema).mutation(async ({ ctx, input }) => {
      if (!/^[A-Za-z0-9+/]+={0,2}$/.test(input.data) || input.data.length % 4 !== 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "O arquivo de imagem não é válido." });
      }
      const buffer = Buffer.from(input.data, "base64");
      const limit = input.target === "avatar" ? 2 * 1024 * 1024 : 5 * 1024 * 1024;
      if (buffer.length > limit) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: `A imagem excede o limite de ${input.target === "avatar" ? "2" : "5"} MB.` });
      if (!validImageBytes(buffer, input.mimeType)) throw new TRPCError({ code: "BAD_REQUEST", message: "Use uma imagem JPG, PNG ou WebP válida." });
      const extension = input.mimeType === "image/jpeg" ? "jpg" : input.mimeType === "image/png" ? "png" : "webp";
      const uploaded = await storagePut(`users/${ctx.user.id}/${input.target}.${extension}`, buffer, input.mimeType);
      if (input.target === "avatar") await updateUserAvatar(ctx.user.id, uploaded.url);
      else await updateUserBackground(ctx.user.id, uploaded.url);
      return { url: uploaded.url };
    }),
    clearAvatar: protectedProcedure.mutation(async ({ ctx }) => {
      await updateUserAvatar(ctx.user.id, null);
      return { success: true };
    }),
    clearBackground: protectedProcedure.mutation(async ({ ctx }) => {
      await updateUserBackground(ctx.user.id, null);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
