import { describe, expect, it } from "vitest";
import { isDesignatedAdminEmail } from "./_core/adminAccess";

describe("designated administrator access", () => {
  it("matches the authenticated email case-insensitively", () => {
    expect(isDesignatedAdminEmail("vmssyt2026@gmail.com")).toBe(true);
    expect(isDesignatedAdminEmail(" VMSSYT2026@GMAIL.COM ")).toBe(true);
  });

  it("does not grant access to missing or different email identities", () => {
    expect(isDesignatedAdminEmail(undefined)).toBe(false);
    expect(isDesignatedAdminEmail(null)).toBe(false);
    expect(isDesignatedAdminEmail("another@example.com")).toBe(false);
    expect(isDesignatedAdminEmail("vmssyt2026+other@gmail.com")).toBe(false);
  });
});
