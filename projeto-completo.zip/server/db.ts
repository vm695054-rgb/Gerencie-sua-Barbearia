import { and, asc, desc, eq, gt, isNotNull, isNull, ne } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { Appointment, InsertUser, User, appointments, barbershopSettings, barbershops, users } from "../drizzle/schema";
import { isDesignatedAdminEmail } from "./_core/adminAccess";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    values.lastSignedIn = user.lastSignedIn ?? new Date();
    updateSet.lastSignedIn = values.lastSignedIn;
    values.lastActiveAt = user.lastActiveAt ?? new Date();
    updateSet.lastActiveAt = values.lastActiveAt;
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  const user = result[0];
  if (user?.role === "admin" && !isDesignatedAdminEmail(user.email)) return { ...user, role: "user" as const };
  return user;
}

export async function updateCustomerProfile(id: number, profile: { firstName: string; lastName: string; birthDate: string; phone: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ ...profile, lastActiveAt: new Date() }).where(eq(users.id, id));
}

export async function updateCustomerName(id: number, profile: { firstName: string; lastName: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ ...profile, lastActiveAt: new Date() }).where(eq(users.id, id));
}

export async function getBarbershopById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.select().from(barbershops).where(eq(barbershops.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getOwnedBarbershop(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.select().from(barbershops).where(eq(barbershops.ownerUserId, userId)).limit(1);
  return result[0] ?? null;
}

export async function getBarbershopForUser(user: Pick<User, "id" | "role" | "selectedBarbershopId">) {
  if (user.role === "barber" || user.role === "admin") {
    let owned = await getOwnedBarbershop(user.id);
    if (owned) return owned;
    if (user.role === "admin") {
      await claimDefaultBarbershop(user.id);
      owned = await getOwnedBarbershop(user.id);
      return owned;
    }
    return null;
  }
  if (!user.selectedBarbershopId) return null;
  const selected = await getBarbershopById(user.selectedBarbershopId);
  return selected?.ownerUserId ? selected : null;
}

export async function getBarbershopNameForUser(user: Pick<User, "id" | "role" | "selectedBarbershopId">) {
  const shop = await getBarbershopForUser(user);
  return shop?.name ?? null;
}

export async function listBarbershops() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ id: barbershops.id, name: barbershops.name })
    .from(barbershops)
    .where(isNotNull(barbershops.ownerUserId))
    .orderBy(asc(barbershops.name));
}

export async function createBarbershop(ownerUserId: number, name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getOwnedBarbershop(ownerUserId);
  if (existing) return null;
  const inserted = await db.insert(barbershops).values({ ownerUserId, name }).$returningId();
  const id = inserted[0]?.id;
  if (!id) throw new Error("The new barbershop ID was not returned");
  return getBarbershopById(id);
}

export async function selectBarbershop(userId: number, shopId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const shop = await db.select({ id: barbershops.id }).from(barbershops)
    .where(and(eq(barbershops.id, shopId), isNotNull(barbershops.ownerUserId))).limit(1);
  if (!shop.length) return false;
  await db.update(users).set({ selectedBarbershopId: shopId, lastActiveAt: new Date() }).where(eq(users.id, userId));
  return true;
}

export async function renameOwnedBarbershop(userId: number, name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const shop = await getOwnedBarbershop(userId);
  if (!shop) return false;
  await db.update(barbershops).set({ name, updatedAt: new Date() }).where(and(eq(barbershops.id, shop.id), eq(barbershops.ownerUserId, userId)));
  return true;
}

export async function claimDefaultBarbershop(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const legacy = await db.select({ name: barbershopSettings.shopName }).from(barbershopSettings)
    .where(eq(barbershopSettings.id, 1)).limit(1);
  const legacyName = legacy[0]?.name?.trim();
  await db.update(barbershops).set({ ownerUserId: userId, ...(legacyName ? { name: legacyName } : {}), updatedAt: new Date() })
    .where(and(eq(barbershops.id, 1), isNull(barbershops.ownerUserId)));
}

export async function updateUserPreferences(id: number, preferences: { musicTrack: string; backgroundStyle: "default" | "scissors" | "clippers" | "custom" }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ ...preferences, lastActiveAt: new Date() }).where(eq(users.id, id));
}

export async function updateUserAvatar(id: number, avatarUrl: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ avatarUrl, lastActiveAt: new Date() }).where(eq(users.id, id));
}

export async function updateUserBackground(id: number, backgroundImage: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ backgroundImage, backgroundStyle: backgroundImage ? "custom" : "default", lastActiveAt: new Date() }).where(eq(users.id, id));
}

export async function touchUserActivity(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ lastActiveAt: new Date() }).where(eq(users.id, id));
}

export async function markUserInactive(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ lastActiveAt: null }).where(eq(users.id, id));
}

export async function listBarbershopClients(shopId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ id: users.id, firstName: users.firstName, lastName: users.lastName, displayName: users.name, lastActiveAt: users.lastActiveAt })
    .from(users)
    .where(and(eq(users.role, "user"), eq(users.selectedBarbershopId, shopId)))
    .orderBy(asc(users.firstName), asc(users.lastName));
}

export async function listAppointmentsForShop(shopId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(appointments).where(eq(appointments.barbershopId, shopId))
    .orderBy(desc(appointments.appointmentDate), desc(appointments.appointmentTime));
}

export async function listAppointmentsForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db.select({ appointment: appointments, barbershopName: barbershops.name })
    .from(appointments)
    .leftJoin(barbershops, eq(appointments.barbershopId, barbershops.id))
    .where(eq(appointments.customerUserId, userId))
    .orderBy(desc(appointments.appointmentDate), desc(appointments.appointmentTime));
  return rows.map(({ appointment, barbershopName }) => ({ ...appointment, barbershopName }));
}

export async function createAppointment(input: Omit<Appointment, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const conflict = await db.select({ id: appointments.id }).from(appointments).where(and(
    eq(appointments.barbershopId, input.barbershopId),
    eq(appointments.appointmentDate, input.appointmentDate),
    eq(appointments.appointmentTime, input.appointmentTime),
    ne(appointments.status, "cancelled"),
  )).limit(1);
  if (conflict.length) return false;
  await db.insert(appointments).values(input);
  return true;
}

export async function updateAppointmentStatus(id: number, shopId: number, status: "pending" | "confirmed" | "cancelled") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: appointments.id }).from(appointments)
    .where(and(eq(appointments.id, id), eq(appointments.barbershopId, shopId))).limit(1);
  if (!existing.length) return false;
  await db.update(appointments).set({ status }).where(and(eq(appointments.id, id), eq(appointments.barbershopId, shopId)));
  return true;
}

export type BarberClient = Awaited<ReturnType<typeof listBarbershopClients>>[number];
export type ShopAppointment = Awaited<ReturnType<typeof listAppointmentsForShop>>[number];
