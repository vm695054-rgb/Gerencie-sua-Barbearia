import { COOKIE_NAME, ONE_YEAR_MS, OAUTH_STATE_COOKIE, decodeOAuthState } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { isDesignatedAdminEmail } from "./adminAccess";
import { getSessionCookieOptions } from "./cookies";
import { ENV } from "./env";
import { sdk } from "./sdk";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

const ALLOWED_RETURN_PATHS = new Set(["/", "/entrar?tipo=cliente", "/entrar?tipo=cabeleireiro", "/entrar?tipo=administrador"]);

function normalizePublicOrigin(value: string) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) return null;
    return url.origin;
  } catch {
    return null;
  }
}

export function allowedOAuthCallbackUri(redirectUri: string, publicOrigins: string[]) {
  try {
    const requested = new URL(redirectUri);
    if (requested.protocol !== "https:" || requested.username || requested.password || requested.search || requested.hash || requested.pathname !== "/api/oauth/callback") return null;
    const allowlist = new Set(publicOrigins.map(normalizePublicOrigin).filter((origin): origin is string => Boolean(origin)));
    if (!allowlist.has(requested.origin)) return null;
    return `${requested.origin}/api/oauth/callback`;
  } catch {
    return null;
  }
}

function getOAuthAllowedOrigins() {
  return [
    "https://8328-ikyp9f9pviasr61xgw6dw-f428a8f1.us3.manus.computer",
    ENV.previewPublicOrigin,
    ENV.runtimePublicOrigin,
  ];
}

export function registerOAuthRoutes(app: Express) {
  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }

    // CSRF guard: the nonce in `state` must match the one-time cookie that
    // startLogin set in the browser that began this login. An attacker can
    // forge `state`, but cannot plant this cookie in the victim's browser.
    const oauthState = decodeOAuthState(state);
    const expectedRedirectUri = allowedOAuthCallbackUri(oauthState.redirectUri, getOAuthAllowedOrigins());
    if (!expectedRedirectUri || oauthState.redirectUri !== expectedRedirectUri) {
      res.status(403).json({ error: "invalid oauth redirect uri" });
      return;
    }
    const expectedNonce = parseCookieHeader(req.headers.cookie ?? "")[OAUTH_STATE_COOKIE];
    if (!oauthState.nonce || oauthState.nonce !== expectedNonce) {
      res.status(403).json({ error: "invalid oauth state" });
      return;
    }
    const returnTo = ALLOWED_RETURN_PATHS.has(oauthState.returnTo ?? "") ? oauthState.returnTo! : "/";
    res.clearCookie(OAUTH_STATE_COOKIE, { path: "/", secure: true, sameSite: "none" });

    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, expectedRedirectUri);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);

      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }

      const designatedAdmin = isDesignatedAdminEmail(userInfo.email);
      const requestedBarber = returnTo === "/entrar?tipo=cabeleireiro";
      await db.upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: new Date(),
        lastActiveAt: new Date(),
        ...(designatedAdmin ? { role: "admin" as const } : requestedBarber ? { role: "barber" as const } : {}),
      });

      const user = await db.getUserByOpenId(userInfo.openId);
      if (user?.role === "admin" && designatedAdmin) await db.claimDefaultBarbershop(user.id);

      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.redirect(302, returnTo);
    } catch (error) {
      console.error("[OAuth] Callback failed", error instanceof Error ? error.message : "unknown error");
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}
