const designatedAdminEmail = "vmssyt2026@gmail.com";

/** Check the authenticated OAuth identity on the server; the UI never receives this allowlist. */
export function isDesignatedAdminEmail(email: string | null | undefined): boolean {
  return typeof email === "string" && email.trim().toLowerCase() === designatedAdminEmail;
}
