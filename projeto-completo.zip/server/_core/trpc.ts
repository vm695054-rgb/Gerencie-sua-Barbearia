import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { isDesignatedAdminEmail } from "./adminAccess";

const t = initTRPC.context<TrpcContext>().create({ transformer: superjson });

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  if (!opts.ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  return opts.next({ ctx: { ...opts.ctx, user: opts.ctx.user } });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const barberProcedure = t.procedure.use(t.middleware(async opts => {
  const { ctx } = opts;
  if (!ctx.user || (ctx.user.role !== "barber" && !(ctx.user.role === "admin" && isDesignatedAdminEmail(ctx.user.email)))) {
    throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  }
  return opts.next({ ctx: { ...ctx, user: ctx.user } });
}));

export const adminProcedure = t.procedure.use(t.middleware(async opts => {
  const { ctx } = opts;
  if (!ctx.user || ctx.user.role !== "admin" || !isDesignatedAdminEmail(ctx.user.email)) {
    throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  }
  return opts.next({ ctx: { ...ctx, user: ctx.user } });
}));
