import { describe, expect, it } from "vitest";
import { allowedOAuthCallbackUri } from "./_core/oauth";

describe("OAuth callback origin allowlist", () => {
  const origins = ["https://preview.example", "https://barber.example"];

  it("accepts only an exact callback path on an explicitly configured public origin", () => {
    expect(allowedOAuthCallbackUri("https://preview.example/api/oauth/callback", origins))
      .toBe("https://preview.example/api/oauth/callback");
    expect(allowedOAuthCallbackUri("https://barber.example/api/oauth/callback", origins))
      .toBe("https://barber.example/api/oauth/callback");
  });

  it("rejects an alternate host even when its syntax is valid", () => {
    expect(allowedOAuthCallbackUri("https://attacker.example/api/oauth/callback", origins)).toBeNull();
  });

  it("rejects HTTP, a different path, query, fragment, or credentials", () => {
    expect(allowedOAuthCallbackUri("http://preview.example/api/oauth/callback", origins)).toBeNull();
    expect(allowedOAuthCallbackUri("https://preview.example/other", origins)).toBeNull();
    expect(allowedOAuthCallbackUri("https://preview.example/api/oauth/callback?next=/", origins)).toBeNull();
    expect(allowedOAuthCallbackUri("https://preview.example/api/oauth/callback#fragment", origins)).toBeNull();
    expect(allowedOAuthCallbackUri("https://user@preview.example/api/oauth/callback", origins)).toBeNull();
  });
});
