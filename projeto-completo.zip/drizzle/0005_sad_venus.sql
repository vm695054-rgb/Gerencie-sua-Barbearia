CREATE TABLE `barbershops` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerUserId` int,
	`name` varchar(80) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `barbershops_id` PRIMARY KEY(`id`),
	CONSTRAINT `barbershops_owner_user_unique` UNIQUE(`ownerUserId`)
);
--> statement-breakpoint
INSERT INTO `barbershops` (`id`, `ownerUserId`, `name`, `createdAt`, `updatedAt`) VALUES (1, NULL, 'Barbearia', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
--> statement-breakpoint
ALTER TABLE `appointments` ADD `barbershopId` int DEFAULT 1 NOT NULL;
--> statement-breakpoint
ALTER TABLE `users` ADD `selectedBarbershopId` int;
--> statement-breakpoint
UPDATE `users` SET `selectedBarbershopId` = 1 WHERE `role` = 'user' AND `selectedBarbershopId` IS NULL;
--> statement-breakpoint
ALTER TABLE `barbershops` ADD CONSTRAINT `barbershops_ownerUserId_users_id_fk` FOREIGN KEY (`ownerUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `appointments` ADD CONSTRAINT `appointments_barbershopId_barbershops_id_fk` FOREIGN KEY (`barbershopId`) REFERENCES `barbershops`(`id`) ON DELETE restrict ON UPDATE no action;
