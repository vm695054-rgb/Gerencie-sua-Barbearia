CREATE TABLE `barbershop_settings` (
	`id` int NOT NULL,
	`shopName` varchar(80) NOT NULL DEFAULT 'Barbearia',
	`updatedByUserId` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `barbershop_settings_id` PRIMARY KEY(`id`)
);
