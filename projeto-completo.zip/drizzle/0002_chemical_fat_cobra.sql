ALTER TABLE `users` MODIFY COLUMN `role` enum('user','barber_pending','barber','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `firstName` varchar(80);--> statement-breakpoint
ALTER TABLE `users` ADD `lastName` varchar(80);--> statement-breakpoint
ALTER TABLE `users` ADD `birthDate` varchar(10);--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `lastActiveAt` timestamp;