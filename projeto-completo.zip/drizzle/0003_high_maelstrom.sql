ALTER TABLE `users` ADD `avatarUrl` varchar(512);--> statement-breakpoint
ALTER TABLE `users` ADD `musicTrack` varchar(32) DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `backgroundStyle` enum('default','scissors','clippers','custom') DEFAULT 'default' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `backgroundImage` varchar(512);