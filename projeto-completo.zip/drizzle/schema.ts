import { int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/** Accounts backed by Manus OAuth; only the designated authenticated identity is an admin. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "barber_pending", "barber", "admin"]).default("user").notNull(),
  firstName: varchar("firstName", { length: 80 }),
  selectedBarbershopId: int("selectedBarbershopId"),
  lastName: varchar("lastName", { length: 80 }),
  birthDate: varchar("birthDate", { length: 10 }),
  phone: varchar("phone", { length: 32 }),
  lastActiveAt: timestamp("lastActiveAt"),
  avatarUrl: varchar("avatarUrl", { length: 512 }),
  musicTrack: varchar("musicTrack", { length: 32 }).default("none").notNull(),
  backgroundStyle: mysqlEnum("backgroundStyle", ["default", "scissors", "clippers", "custom"]).default("default").notNull(),
  backgroundImage: varchar("backgroundImage", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** Global display name chosen by the designated barbershop administrator. */
export const barbershopSettings = mysqlTable("barbershop_settings", {
  id: int("id").primaryKey(),
  shopName: varchar("shopName", { length: 80 }).notNull().default("Barbearia"),
  updatedByUserId: int("updatedByUserId"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** A barber-owned shop. One account can own at most one shop. */
export const barbershops = mysqlTable("barbershops", {
  id: int("id").autoincrement().primaryKey(),
  ownerUserId: int("ownerUserId").references(() => users.id, { onDelete: "set null" }),
  name: varchar("name", { length: 80 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ ownerUserIdUnique: uniqueIndex("barbershops_owner_user_unique").on(table.ownerUserId) }));

/** Appointment requests and barber-entered bookings. */
export const appointments = mysqlTable("appointments", {
  id: int("id").autoincrement().primaryKey(),
  barbershopId: int("barbershopId").notNull().default(1).references(() => barbershops.id, { onDelete: "restrict" }),
  customerUserId: int("customerUserId"),
  createdByUserId: int("createdByUserId").notNull(),
  customerName: varchar("customerName", { length: 160 }).notNull(),
  customerPhone: varchar("customerPhone", { length: 32 }).notNull(),
  service: mysqlEnum("service", ["degrade", "pigmentacao", "barba", "pe-cabelo"]).notNull(),
  appointmentDate: varchar("appointmentDate", { length: 10 }).notNull(),
  appointmentTime: varchar("appointmentTime", { length: 5 }).notNull(),
  note: varchar("note", { length: 500 }),
  status: mysqlEnum("status", ["pending", "confirmed", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;
