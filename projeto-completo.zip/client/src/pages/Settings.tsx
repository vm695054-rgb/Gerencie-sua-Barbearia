import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { ArrowLeft, Check, ImagePlus, Music2, Moon, Scissors, Sun, UserRound, Volume2, Pause, Play, X } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { useTheme } from "@/contexts/ThemeContext";
import { MUSIC_TRACKS, useMusic, type MusicTrackId } from "@/contexts/MusicContext";
import { trpc } from "@/lib/trpc";
import { useAuth } from "../_core/hooks/useAuth";

const backgrounds = [
  { id: "default", title: "Original", description: "O visual da barbearia" },
  { id: "scissors", title: "Tesouras", description: "Padrão de tesouras" },
  { id: "clippers", title: "Máquinas", description: "Padrão de máquinas" },
] as const;
type Background = (typeof backgrounds)[number]["id"] | "custom";

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== "string" || !result.includes(",")) return reject(new Error("Não consegui ler essa imagem."));
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.onerror = () => reject(new Error("Não consegui ler essa imagem."));
    reader.readAsDataURL(file);
  });
}

export default function Settings() {
  const auth = useAuth();
  const { theme, toggleTheme } = useTheme();
  const music = useMusic();
  const utils = trpc.useUtils();
  const avatarInput = useRef<HTMLInputElement>(null);
  const backgroundInput = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState<"avatar" | "background" | null>(null);
  const [nameDraft, setNameDraft] = useState({ firstName: "", lastName: "" });
  const [shopNameDraft, setShopNameDraft] = useState("");
  const businessNameQuery = trpc.settings.businessName.useQuery(undefined, { enabled: Boolean(auth.user) });
  const shopName = auth.user ? businessNameQuery.data ?? "Barbearia" : "Gerencie sua barbearia";

  useEffect(() => { setNameDraft({ firstName: auth.user?.firstName ?? "", lastName: auth.user?.lastName ?? "" }); }, [auth.user?.firstName, auth.user?.lastName]);
  useEffect(() => { if (businessNameQuery.data) setShopNameDraft(businessNameQuery.data); }, [businessNameQuery.data]);

  const updateName = trpc.auth.updateMyName.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); toast.success("Nome da conta atualizado."); },
    onError: error => toast.error(error.message),
  });
  const saveBusinessName = trpc.settings.saveBusinessName.useMutation({
    onSuccess: async () => { await Promise.all([utils.settings.businessName.invalidate(), utils.shops.mine.invalidate(), utils.shops.list.invalidate()]); toast.success("Nome da barbearia atualizado."); },
    onError: error => toast.error(error.message),
  });

  const savePreferences = trpc.settings.save.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); toast.success("Preferência salva."); },
    onError: error => toast.error(error.message),
  });
  const uploadImage = trpc.settings.uploadImage.useMutation({
    onSuccess: async (_result, variables) => {
      setUploading(null);
      await utils.auth.me.invalidate();
      toast.success(variables.target === "avatar" ? "Foto de perfil atualizada." : "Fundo personalizado atualizado.");
    },
    onError: error => { setUploading(null); toast.error(error.message); },
  });
  const clearAvatar = trpc.settings.clearAvatar.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); toast.success("Foto removida; o avatar padrão está ativo."); },
    onError: error => toast.error(error.message),
  });
  const clearBackground = trpc.settings.clearBackground.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); toast.success("Fundo personalizado removido."); },
    onError: error => toast.error(error.message),
  });

  const upload = async (event: ChangeEvent<HTMLInputElement>, target: "avatar" | "background") => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = "";
    if (!file) return;
    const maxBytes = target === "avatar" ? 2 * 1024 * 1024 : 5 * 1024 * 1024;
    if (file.size > maxBytes) { toast.error(`A imagem deve ter até ${target === "avatar" ? "2 MB" : "5 MB"}.`); return; }
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) { toast.error("Escolha uma imagem JPG, PNG ou WebP."); return; }
    setUploading(target);
    try {
      uploadImage.mutate({ target, mimeType: file.type as "image/jpeg" | "image/png" | "image/webp", data: await fileToBase64(file) });
    } catch (error) {
      setUploading(null);
      toast.error(error instanceof Error ? error.message : "Falha ao preparar a imagem.");
    }
  };

  const chooseBackground = (backgroundStyle: Background) => {
    if (!auth.user) { toast.info("Entre como cliente para salvar essa personalização."); return; }
    if (backgroundStyle === "custom" && !auth.user.backgroundImage) { backgroundInput.current?.click(); return; }
    savePreferences.mutate({ musicTrack: (auth.user.musicTrack ?? "none") as MusicTrackId, backgroundStyle });
  };

  const chooseMusic = (musicTrack: MusicTrackId) => {
    if (!auth.user) { toast.info("Entre como cliente para salvar essa preferência."); return; }
    savePreferences.mutate({ musicTrack, backgroundStyle: (auth.user.backgroundStyle ?? "default") as Background });
  };

  const submitName = (event: FormEvent) => { event.preventDefault(); updateName.mutate(nameDraft); };
  const submitBusinessName = (event: FormEvent) => { event.preventDefault(); saveBusinessName.mutate({ name: shopNameDraft }); };

  return (
    <main className="settings-page">
      <Link href="/" className="back-link"><ArrowLeft size={17} /> {auth.user ? shopName : "Voltar à página inicial"}</Link>
      <section className="settings-panel settings-expanded">
        <span className="eyebrow">PERSONALIZAÇÃO</span>
        <h1>Configurações</h1>
        <p>{auth.user ? `Personalize sua experiência na ${shopName}.` : "Escolha como prefere ver e ouvir o site."}</p>

        <section className="settings-group" aria-labelledby="my-account-heading">
          <div className="settings-group-heading"><span className="settings-group-icon"><UserRound size={18} /></span><div><h2 id="my-account-heading">Minha conta</h2><p>Foto de perfil opcional</p></div></div>
          {!auth.user ? <div className="settings-login-prompt"><span>Entre como cliente para personalizar sua conta.</span><Link href="/entrar?tipo=cliente" className="button button-outline">Entrar como cliente</Link></div> : <>
            <div className="account-photo-row">
            <div className="account-avatar" aria-label={auth.user.avatarUrl ? "Foto de perfil" : "Avatar padrão"}>{auth.user.avatarUrl ? <img src={auth.user.avatarUrl} alt="Foto do perfil" /> : <UserRound size={34} strokeWidth={1.5} />}</div>
            <div className="account-photo-copy"><strong>{auth.user.firstName ? `${auth.user.firstName} ${auth.user.lastName ?? ""}`.trim() : "Sua foto"}</strong><span>{auth.user.avatarUrl ? "Sua foto aparece no perfil." : "Você está usando o avatar padrão."}</span><div className="settings-inline-actions"><button className="button button-outline small-button" disabled={Boolean(uploading)} onClick={() => avatarInput.current?.click()}>{uploading === "avatar" ? "Enviando…" : <><ImagePlus size={15} /> Escolher foto</>}</button>{auth.user.avatarUrl && <button className="text-button" disabled={clearAvatar.isPending} onClick={() => clearAvatar.mutate()}><X size={14} /> Sem foto</button>}</div></div>
            <input ref={avatarInput} className="visually-hidden" type="file" accept="image/jpeg,image/png,image/webp" aria-label="Escolher foto de perfil" onChange={event => void upload(event, "avatar")} />
          </div><form className="account-name-form" onSubmit={submitName}>
            <label>Nome<input required minLength={1} maxLength={80} autoComplete="given-name" value={nameDraft.firstName} onChange={event => setNameDraft({ ...nameDraft, firstName: event.target.value })} /></label>
            <label>Sobrenome<input required minLength={1} maxLength={80} autoComplete="family-name" value={nameDraft.lastName} onChange={event => setNameDraft({ ...nameDraft, lastName: event.target.value })} /></label>
            <button className="button button-outline small-button" disabled={updateName.isPending}>{updateName.isPending ? "Salvando…" : "Salvar nome"}</button>
          </form></>}
        </section>

        {(auth.user?.role === "admin" || auth.user?.role === "barber") && businessNameQuery.data && <section className="settings-group" aria-labelledby="business-name-heading">
          <div className="settings-group-heading"><span className="settings-group-icon"><Scissors size={18} /></span><div><h2 id="business-name-heading">Personalizar nome da barbearia</h2><p>Esse nome aparece no alto para clientes que escolheram sua loja.</p></div></div>
          <form className="business-name-form" onSubmit={submitBusinessName}>
            <label>Nome da barbearia<input required minLength={2} maxLength={80} value={shopNameDraft} onChange={event => setShopNameDraft(event.target.value)} placeholder="Ex.: Barbearia do Messi" /></label>
            <button className="button button-primary small-button" disabled={saveBusinessName.isPending}>{saveBusinessName.isPending ? "Salvando…" : "Salvar nome da barbearia"}</button>
          </form>
        </section>}

        <section className="settings-group" aria-labelledby="music-heading">
          <div className="settings-group-heading"><span className="settings-group-icon"><Music2 size={18} /></span><div><h2 id="music-heading">Música</h2><p>Opcional — começa desligada, sem tocar sozinha</p></div></div>
          {!auth.user && <div className="settings-login-prompt"><span>Entre como cliente para salvar sua escolha.</span><Link href="/entrar?tipo=cliente" className="secondary-link">Iniciar sessão</Link></div>}
          <div className="music-options">
            <button className={`music-option ${music.track === "none" ? "selected" : ""}`} onClick={() => chooseMusic("none")} disabled={savePreferences.isPending}><span className="music-option-icon"><X size={16} /></span><span><strong>Nenhuma música</strong><small>Site em silêncio</small></span>{music.track === "none" && <Check size={17} />}</button>
            {MUSIC_TRACKS.map(track => <article key={track.id} className={`music-option ${music.track === track.id ? "selected" : ""}`}>
              <span className="music-option-icon"><Music2 size={16} /></span>
              <span className="music-option-copy"><strong>{track.title}</strong><small>{track.artist}</small>{track.sourceUrl && <a className="music-source" href={track.sourceUrl} target="_blank" rel="noopener noreferrer">Pixabay · fonte e licença da faixa</a>}</span>
              <button className="music-option-select" type="button" disabled={!auth.user || savePreferences.isPending} onClick={() => chooseMusic(track.id)}>{music.track === track.id ? <Check size={16} /> : "Escolher"}</button>
            </article>)}
          </div>
          <p className="settings-footnote">A faixa do Pixabay é usada dentro do site, com origem identificada; o arquivo não é redistribuído separadamente. As outras faixas são originais geradas para o projeto e não são declaradas como domínio público.</p>
          {auth.user && music.track !== "none" && <div className="music-preview-controls"><button className="button button-outline" onClick={() => music.isPlaying ? music.pause() : void music.play()}>{music.isPlaying ? <Pause size={15} /> : <Play size={15} />}{music.isPlaying ? "Pausar" : "Ouvir agora"}</button><span><Volume2 size={15} /> A música continua ao navegar; pause por aqui.</span></div>}
        </section>

        <section className="settings-group" aria-labelledby="wallpaper-heading">
          <div className="settings-group-heading"><span className="settings-group-icon"><Scissors size={18} /></span><div><h2 id="wallpaper-heading">Personalizar fundo</h2><p>Escolha uma textura discreta ou uma foto da galeria</p></div></div>
          {!auth.user && <div className="settings-login-prompt"><span>Entre como cliente para salvar seu fundo em todos os aparelhos.</span><Link href="/entrar?tipo=cliente" className="secondary-link">Iniciar sessão</Link></div>}
          <div className="wallpaper-options">{backgrounds.map(background => <button type="button" key={background.id} className={`wallpaper-option ${auth.user?.backgroundStyle === background.id || (!auth.user?.backgroundStyle && background.id === "default") ? "selected" : ""}`} onClick={() => chooseBackground(background.id)} disabled={savePreferences.isPending}>
            <span className={`wallpaper-preview wallpaper-${background.id}`} aria-hidden="true">{background.id === "default" ? <Check size={18} /> : background.id === "scissors" ? <Scissors size={23} /> : <span className="clipper-symbol" />}</span><strong>{background.title}</strong><small>{background.description}</small>
          </button>)}
            <button type="button" className={`wallpaper-option ${auth.user?.backgroundStyle === "custom" ? "selected" : ""}`} onClick={() => backgroundInput.current?.click()} disabled={Boolean(uploading)}><span className="wallpaper-preview wallpaper-custom">{auth.user?.backgroundImage ? <img src={auth.user.backgroundImage} alt="" /> : <ImagePlus size={22} />}</span><strong>{uploading === "background" ? "Enviando…" : "Galeria"}</strong><small>{auth.user?.backgroundImage ? "Trocar minha foto" : "Escolher minha imagem"}</small></button>
          </div>
          <input ref={backgroundInput} className="visually-hidden" type="file" accept="image/jpeg,image/png,image/webp" aria-label="Escolher foto para fundo" onChange={event => void upload(event, "background")} />
          {auth.user?.backgroundStyle === "custom" && <button className="text-button clear-background" disabled={clearBackground.isPending} onClick={() => clearBackground.mutate()}><X size={14} /> Voltar ao fundo padrão</button>}
        </section>

        <section className="settings-group" aria-labelledby="theme-heading">
          <div className="settings-group-heading"><span className="settings-group-icon">{theme === "light" ? <Sun size={18} /> : <Moon size={18} />}</span><div><h2 id="theme-heading">Claro ou escuro</h2><p>Essa opção fica salva neste dispositivo</p></div></div>
          <div className="theme-options">
            <button onClick={() => theme !== "light" && toggleTheme?.()} className={`theme-option ${theme === "light" ? "selected" : ""}`}><Sun size={22} /><span><strong>Claro</strong><small>Leve e luminoso</small></span>{theme === "light" && <Check className="theme-check" size={18} />}</button>
            <button onClick={() => theme !== "dark" && toggleTheme?.()} className={`theme-option ${theme === "dark" ? "selected" : ""}`}><Moon size={22} /><span><strong>Escuro</strong><small>Confortável à noite</small></span>{theme === "dark" && <Check className="theme-check" size={18} />}</button>
          </div>
        </section>

        <Link href="/" className="button button-outline settings-done">Concluir</Link>
      </section>
    </main>
  );
}
