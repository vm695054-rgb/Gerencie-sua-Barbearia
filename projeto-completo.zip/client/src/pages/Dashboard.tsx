import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, CalendarDays, Check, Clock3, LogOut, Plus, Scissors, ShieldAlert, UserPlus, UsersRound, X } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { useAuth } from "../_core/hooks/useAuth";

const services = [
  { value: "degrade", label: "Degradê" },
  { value: "pigmentacao", label: "Pigmentação" },
  { value: "barba", label: "Barba" },
  { value: "pe-cabelo", label: "Pé do cabelo" },
] as const;
type Service = (typeof services)[number]["value"];
type Form = { customerName: string; customerPhone: string; service: Service; appointmentDate: string; appointmentTime: string; note: string };
const emptyForm = (): Form => ({ customerName: "", customerPhone: "", service: "degrade", appointmentDate: "", appointmentTime: "", note: "" });
const prettyDate = (value: string) => value ? new Date(`${value}T12:00:00`).toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "short" }) : "—";
const brazilDateParts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
const brazilDateValues = Object.fromEntries(brazilDateParts.map(part => [part.type, part.value]));
const todayInBrazil = `${brazilDateValues.year}-${brazilDateValues.month}-${brazilDateValues.day}`;

type AppointmentCardData = { id: number; customerName: string; customerPhone: string; service: string; appointmentDate: string; appointmentTime: string; note: string | null; status: string; barbershopName?: string | null };

export default function Dashboard() {
  const auth = useAuth();
  const [form, setForm] = useState<Form>(emptyForm);
  const [shopNameDraft, setShopNameDraft] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [activeSection, setActiveSection] = useState<"appointments" | "clients">("appointments");
  const utils = trpc.useUtils();
  const isBarber = auth.user?.role === "admin" || auth.user?.role === "barber";
  const businessNameQuery = trpc.settings.businessName.useQuery(undefined, { enabled: Boolean(auth.user), refetchInterval: auth.user ? 60_000 : false });
  const shop = trpc.shops.mine.useQuery(undefined, { enabled: Boolean(isBarber) });
  const shopName = businessNameQuery.data ?? (isBarber ? "Criar barbearia" : "Escolha uma barbearia");
  const mine = trpc.appointments.mine.useQuery(undefined, { enabled: Boolean(auth.user && !isBarber) });
  const all = trpc.appointments.list.useQuery(undefined, { enabled: Boolean(isBarber && shop.data?.id) });
  const clients = trpc.shops.clients.useQuery(undefined, { enabled: Boolean(isBarber && shop.data?.id && activeSection === "clients"), refetchInterval: 15_000 });

  const createShop = trpc.shops.create.useMutation({
    onSuccess: async () => {
      toast.success("Sua barbearia foi criada.");
      await Promise.all([utils.shops.mine.invalidate(), utils.shops.list.invalidate(), utils.settings.businessName.invalidate()]);
    },
    onError: error => toast.error(error.message),
  });
  const createManual = trpc.appointments.createForCustomer.useMutation({
    onSuccess: async () => { toast.success("Horário adicionado à agenda."); setForm(emptyForm()); setShowForm(false); await utils.appointments.list.invalidate(); },
    onError: error => toast.error(error.message),
  });
  const updateStatus = trpc.appointments.updateStatus.useMutation({
    onSuccess: async () => { toast.success("Agenda atualizada."); await utils.appointments.list.invalidate(); },
    onError: error => toast.error(error.message),
  });
  const logout = trpc.auth.logout.useMutation({ onSuccess: async () => { await utils.auth.me.invalidate(); toast.success("Sessão encerrada."); } });

  useEffect(() => { if (!auth.loading && !auth.user) startLogin("client"); }, [auth.loading, auth.user]);
  useEffect(() => { if (shop.data?.name) setShopNameDraft(shop.data.name); }, [shop.data?.name]);
  const saveManual = (event: FormEvent) => { event.preventDefault(); createManual.mutate(form); };
  const saveShop = (event: FormEvent) => { event.preventDefault(); createShop.mutate({ name: shopNameDraft.trim() }); };

  if (auth.loading) return <main className="dashboard-page"><div className="loading-card">Carregando sua agenda…</div></main>;
  if (!auth.user) return <main className="dashboard-page"><div className="loading-card">Redirecionando para entrar…</div></main>;

  if (!isBarber) return (
    <main className="dashboard-page">
      <DashboardHeader user={auth.user} logout={() => logout.mutate()} businessName={shopName} />
      <section className="dashboard-heading"><span className="eyebrow">ÁREA DO CLIENTE</span><h1>{auth.user.firstName ? `Bem-vindo, Cliente ${auth.user.firstName} ${auth.user.lastName ?? ""}`.trim() : "Seus pedidos"}</h1><p>Acompanhe os horários que você solicitou.</p></section>
      {!auth.user.selectedBarbershopId && <div className="shop-selection-reminder"><strong>Você ainda não escolheu uma barbearia.</strong><Link href="/#escolher-barbearia" className="button button-primary">Escolher barbearia</Link></div>}
      <section className="appointment-list">{mine.isLoading ? <div className="empty-state">Buscando seus horários…</div> : mine.data?.length ? mine.data.map(item => <AppointmentCard key={item.id} item={item} />) : <div className="empty-state"><CalendarDays size={28} /><strong>Nenhum pedido por enquanto</strong><Link href="/#agendar" className="button button-primary">Marcar horário</Link></div>}</section>
    </main>
  );

  const activeAppointments = all.data?.filter(item => item.status !== "cancelled") ?? [];
  const hasShop = Boolean(shop.data?.id);

  return (
    <main className="dashboard-page">
      <DashboardHeader user={auth.user} logout={() => logout.mutate()} businessName={shopName} barber />
      <section className="dashboard-heading"><span className="eyebrow">PAINEL DO CABELEIREIRO</span><h1>{shopName}</h1><p>{hasShop ? "Sua agenda e sua clientela, organizadas em um só lugar." : "Crie sua barbearia para começar a receber clientes."}</p></section>

      {shop.isLoading ? <div className="empty-state">Carregando sua barbearia…</div> : !hasShop ? <section className="shop-create-card">
        <div className="shop-create-icon"><Scissors size={24} /></div><span className="eyebrow">SEU ESPAÇO</span><h2>Criar barbearia</h2><p>Escolha um nome. Depois, seus clientes poderão encontrar sua loja e escolher você para o próximo corte.</p>
        <form className="shop-create-form" onSubmit={saveShop}><label>Nome da barbearia<input required minLength={2} maxLength={80} value={shopNameDraft} onChange={event => setShopNameDraft(event.target.value)} placeholder="Ex.: Barbearia do Messi" /></label><button className="button button-primary" disabled={createShop.isPending || shopNameDraft.trim().length < 2}>{createShop.isPending ? "Criando…" : <>Criar minha barbearia <Plus size={16} /></>}</button></form>
      </section> : <>
        <div className="shop-owner-card"><span className="shop-owner-mark"><Scissors size={16} /></span><span><small>SUA BARBEARIA</small><strong>{shop.data?.name}</strong></span><Link href="/configuracoes">Personalizar nome</Link></div>
        <div className="barber-sections" role="tablist" aria-label="Painel do cabeleireiro">
          <button role="tab" aria-selected={activeSection === "appointments"} className={`barber-tab ${activeSection === "appointments" ? "active" : ""}`} onClick={() => setActiveSection("appointments")}><CalendarDays size={17} /> Cortes agendados <span>{activeAppointments.length}</span></button>
          <button role="tab" aria-selected={activeSection === "clients"} className={`barber-tab ${activeSection === "clients" ? "active" : ""}`} onClick={() => setActiveSection("clients")}><UsersRound size={17} /> Clientes da barbearia <span>{clients.data?.length ?? 0}</span></button>
        </div>

        {activeSection === "appointments" && <>
          <div className="agenda-toolbar"><div className="agenda-count"><CalendarDays size={18} /><span><strong>{activeAppointments.length}</strong> horários ativos</span></div><button className="button button-primary" onClick={() => setShowForm(value => !value)}><Plus size={17} /> Cadastrar horário</button></div>
          {showForm && <form className="manual-form" onSubmit={saveManual}><div className="form-title"><UserPlus size={19} /><div><strong>Novo horário</strong><small>Cadastro direto pelo cabeleireiro</small></div></div><div className="form-grid"><label>Nome do cliente<input required minLength={2} maxLength={160} value={form.customerName} onChange={event => setForm({ ...form, customerName: event.target.value })} placeholder="Nome e sobrenome" /></label><label>Telefone<input required minLength={8} maxLength={32} value={form.customerPhone} onChange={event => setForm({ ...form, customerPhone: event.target.value })} placeholder="(00) 00000-0000" /></label><label>Serviço<select value={form.service} onChange={event => setForm({ ...form, service: event.target.value as Service })}>{services.map(service => <option key={service.value} value={service.value}>{service.label}</option>)}</select></label><label>Data<input required type="date" min={todayInBrazil} value={form.appointmentDate} onChange={event => setForm({ ...form, appointmentDate: event.target.value })} /></label><label>Horário<input required type="time" value={form.appointmentTime} onChange={event => setForm({ ...form, appointmentTime: event.target.value })} /></label><label className="wide-field">Observação (opcional)<input maxLength={500} value={form.note} onChange={event => setForm({ ...form, note: event.target.value })} placeholder="Ex.: preferência de corte" /></label></div><div className="form-actions"><button type="button" className="button button-outline" onClick={() => setShowForm(false)}>Cancelar</button><button className="button button-primary" disabled={createManual.isPending}>{createManual.isPending ? "Salvando…" : "Salvar na agenda"}</button></div></form>}
          <section className="appointment-list"><div className="list-heading"><h2>Cortes agendados</h2><span>Pedidos novos precisam de confirmação</span></div>{all.isLoading ? <div className="empty-state">Carregando agenda…</div> : activeAppointments.length ? activeAppointments.map(item => <AppointmentCard key={item.id} item={item} barber onStatus={status => updateStatus.mutate({ id: item.id, status })} />) : <div className="empty-state"><Scissors size={28} /><strong>A agenda está livre</strong><span>Pedidos de clientes aparecerão aqui.</span></div>}</section>
        </>}

        {activeSection === "clients" && <section className="connected-section"><div className="list-heading"><h2>Clientes da barbearia</h2><span>{clients.data?.length ?? 0} pessoas escolheram sua loja</span></div><p className="connected-explanation">Esta lista mostra os nomes dos clientes que escolheram {shop.data?.name}; inclui quem está offline. Só seus nomes e o estado recente da sessão aparecem aqui.</p>{clients.isLoading ? <div className="empty-state">Carregando clientes…</div> : clients.data?.length ? <div className="connected-client-list">{clients.data.map(client => <article className="connected-client" key={client.id}><span className={`online-dot ${client.connected ? "" : "offline"}`} /><span className="connected-client-name">{[client.firstName, client.lastName].filter(Boolean).join(" ") || client.displayName || "Nome ainda não informado"}</span><span className={`connected-label ${client.connected ? "" : "offline"}`}>{client.connected ? "Conectado" : "Offline"}</span></article>)}</div> : <div className="empty-state"><UsersRound size={28} /><strong>Nenhum cliente escolheu sua loja ainda</strong><span>Quando escolherem, seus nomes aparecerão aqui.</span></div>}</section>}
      </>}
    </main>
  );
}

function DashboardHeader({ user, logout, businessName, barber = false }: { user: { firstName?: string | null; lastName?: string | null; name?: string | null }; logout: () => void; businessName: string; barber?: boolean }) {
  const customerName = `${user.firstName ?? ""} ${user.lastName ?? ""}`.trim();
  const greeting = barber ? `Bem-vindo, ${user.firstName || user.name || "cabeleireiro"}` : `Bem-vindo, Cliente ${customerName || user.name || ""}`.trim();
  return <header className="dashboard-top"><Link href="/" className="back-link"><ArrowLeft size={16} /> {businessName}</Link><div className="dashboard-user">{barber && <span className="status-pill confirmed"><ShieldAlert size={13} /> Cabeleireiro</span>}<span className="dashboard-greeting">{greeting}</span><button className="text-button" onClick={logout}>Sair <LogOut size={16} /></button></div></header>;
}

function AppointmentCard({ item, barber = false, onStatus }: { item: AppointmentCardData; barber?: boolean; onStatus?: (status: "confirmed" | "cancelled") => void }) {
  const label = services.find(service => service.value === item.service)?.label ?? item.service;
  return <article className="appointment-card"><div className="appointment-date"><strong>{item.appointmentTime}</strong><span>{prettyDate(item.appointmentDate)}</span></div><div className="appointment-info"><strong>{item.customerName}</strong><span>{label}{item.barbershopName ? ` · ${item.barbershopName}` : ""}{barber && item.customerPhone ? ` · ${item.customerPhone}` : ""}</span>{item.note && <small>{item.note}</small>}</div><div className="appointment-actions"><span className={`status-pill ${item.status}`}><i />{item.status === "pending" ? "Aguardando" : item.status === "confirmed" ? "Confirmado" : "Cancelado"}</span>{barber && item.status === "pending" && <button className="icon-action accept" title="Confirmar horário" onClick={() => onStatus?.("confirmed")}><Check size={16} /></button>}{barber && <button className="icon-action cancel" title="Cancelar horário" onClick={() => onStatus?.("cancelled")}><X size={16} /></button>}</div></article>;
}
