import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ArrowDown, ArrowRight, CalendarDays, Check, ChevronDown, Clock3, Menu as MenuIcon, Scissors, ShieldCheck, Store, UserRound, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { startLogin } from "@/const";
import { useAuth } from "../_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

const services = [
  { value: "degrade", name: "Degradê", short: "Transição precisa, acabamento limpo.", image: "/manus-storage/async-images/bp9LfZdIOdHXCF6AtJ5VbL/image-1.webp", tag: "O clássico" },
  { value: "pigmentacao", name: "Pigmentação", short: "Contorno definido com aspecto natural.", image: "/manus-storage/async-images/bp9LfZdIOdHXCF6AtJ5VbL/image-2.webp", tag: "Definição" },
  { value: "barba", name: "Barba", short: "Desenho e cuidado na medida certa.", image: "/manus-storage/async-images/bp9LfZdIOdHXCF6AtJ5VbL/image-3.webp", tag: "Cuidado" },
  { value: "pe-cabelo", name: "Pé do cabelo", short: "O acabamento que faz diferença.", image: "/manus-storage/async-images/bp9LfZdIOdHXCF6AtJ5VbL/image-4.webp", tag: "Acabamento" },
] as const;
type Service = (typeof services)[number]["value"];
type Form = { service: Service; appointmentDate: string; appointmentTime: string; note: string };
const emptyForm = (): Form => ({ service: "degrade", appointmentDate: "", appointmentTime: "", note: "" });

export default function Home() {
  const auth = useAuth();
  const [, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [shopPickerOpen, setShopPickerOpen] = useState(false);
  const [form, setForm] = useState<Form>(emptyForm);
  const [sent, setSent] = useState(false);
  const utils = trpc.useUtils();
  const businessNameQuery = trpc.settings.businessName.useQuery(undefined, { enabled: Boolean(auth.user), refetchInterval: auth.user ? 60_000 : false });
  const shopName = auth.user ? businessNameQuery.data ?? "Barbearia" : "Gerencie sua barbearia";
  const customerName = auth.user ? `${auth.user.firstName ?? ""} ${auth.user.lastName ?? ""}`.trim() : "";
  const shops = trpc.shops.list.useQuery();
  const hasSelectedShop = Boolean(auth.user?.selectedBarbershopId && shops.data?.some(shop => shop.id === auth.user?.selectedBarbershopId));
  const selectShop = trpc.shops.select.useMutation({
    onSuccess: async (_data, variables) => {
      const selected = shops.data?.find(shop => shop.id === variables.barbershopId);
      sessionStorage.removeItem("barber.pendingShop");
      setShopPickerOpen(false);
      toast.success(selected ? `${selected.name} selecionada.` : "Barbearia selecionada.");
      await Promise.all([utils.auth.me.invalidate(), utils.settings.businessName.invalidate(), utils.appointments.mine.invalidate()]);
    },
    onError: error => toast.error(error.message),
  });
  const request = trpc.appointments.request.useMutation({
    onSuccess: async () => { setSent(true); sessionStorage.removeItem("barber.pendingBooking"); toast.success("Pedido enviado para confirmação."); await utils.appointments.mine.invalidate(); },
    onError: error => { sessionStorage.removeItem("barber.pendingBooking"); toast.error(error.message); },
  });
  const today = useMemo(() => {
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  }, []);

  useEffect(() => {
    if (!auth.user || !hasSelectedShop || request.isPending || request.isSuccess) return;
    const pending = sessionStorage.getItem("barber.pendingBooking");
    if (!pending) return;
    if (!auth.user.firstName || !auth.user.lastName || !auth.user.phone || !auth.user.birthDate) { setLocation("/entrar?tipo=cliente"); return; }
    try { request.mutate(JSON.parse(pending) as Form); } catch { sessionStorage.removeItem("barber.pendingBooking"); }
  }, [auth.user?.id, auth.user?.selectedBarbershopId, auth.user?.firstName, auth.user?.lastName, auth.user?.phone, auth.user?.birthDate, hasSelectedShop, request.isPending, request.isSuccess]);

  const submitBooking = (event: FormEvent) => {
    event.preventDefault();
    if (!form.appointmentDate || !form.appointmentTime) return;
    if (!auth.user || !hasSelectedShop) {
      sessionStorage.setItem("barber.pendingBooking", JSON.stringify(form));
      toast.info("Escolha uma barbearia aberta antes de enviar o pedido.");
      setShopPickerOpen(true);
      return;
    }
    if (!auth.user) return;
    if (!auth.user.firstName || !auth.user.lastName || !auth.user.phone || !auth.user.birthDate) {
      sessionStorage.setItem("barber.pendingBooking", JSON.stringify(form));
      setLocation("/entrar?tipo=cliente");
      return;
    }
    request.mutate(form);
  };

  const chooseService = (service: Service) => {
    setForm(previous => ({ ...previous, service }));
    setSent(false);
    document.getElementById("agendar")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const panelLabel = auth.user?.role === "admin" || auth.user?.role === "barber" ? "Painel do cabeleireiro" : "Meus horários";
  const openShopPicker = () => { setMenuOpen(false); setMobileOpen(false); setShopPickerOpen(true); };
  const chooseShop = (barbershopId: number) => {
    if (!auth.user) {
      sessionStorage.setItem("barber.pendingShop", String(barbershopId));
      startLogin("client");
      return;
    }
    if (auth.user.role !== "user") { toast.error("Entre como cliente para escolher uma barbearia."); return; }
    if (!auth.user.firstName || !auth.user.lastName || !auth.user.birthDate || !auth.user.phone) {
      sessionStorage.setItem("barber.pendingShop", String(barbershopId));
      setShopPickerOpen(false);
      setLocation("/entrar?tipo=cliente");
      return;
    }
    selectShop.mutate({ barbershopId });
  };
  const menuLinks = <>
    {(!auth.user || auth.user.role === "user") && <button type="button" className="menu-dropdown-action" onClick={openShopPicker}>Escolher barbearia <Store size={15} /></button>}
    <a href="#agendar" onClick={() => { setMenuOpen(false); setMobileOpen(false); }}>Marcar horário <ArrowRight size={15} /></a>
    <Link href="/configuracoes" onClick={() => { setMenuOpen(false); setMobileOpen(false); }}>Configurações <ArrowRight size={15} /></Link>
    <Link href="/entrar" onClick={() => { setMenuOpen(false); setMobileOpen(false); }}>Iniciar sessão / Entrar <ArrowRight size={15} /></Link>
    {auth.user && <Link href="/painel" onClick={() => { setMenuOpen(false); setMobileOpen(false); }}>{panelLabel} <ArrowRight size={15} /></Link>}
  </>;

  return (
    <div className="site-shell">
      <header className="site-header">
        <Link href="/" className="wordmark"><span className="brand-mark"><Scissors size={18} /></span><span><strong>{shopName.toUpperCase()}</strong><small>{auth.user ? "HORA MARCADA" : "AGENDA E ATENDIMENTO"}</small></span></Link>
        <nav className="desktop-nav" aria-label="Navegação principal">
          <a href="#servicos">Serviços</a>
          <a href="#agendar">Agendar</a>
          <div className="menu-wrap"><button className={`menu-trigger ${menuOpen ? "active" : ""}`} onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen}>Menu <ChevronDown size={15} /></button>{menuOpen && <div className="menu-dropdown">{menuLinks}</div>}</div>
        </nav>
        <div className="header-actions">{auth.user?.role === "user" && customerName && <span className="header-welcome">Bem-vindo, Cliente <strong>{customerName}</strong></span>}<Link href={auth.user ? "/painel" : "/entrar"} className="header-login"><UserRound size={16} />{auth.user ? "Minha conta" : "Entrar"}</Link><button className="mobile-menu-button" onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}>{mobileOpen ? <X size={20} /> : <MenuIcon size={20} />}</button></div>
        {mobileOpen && <div className="mobile-menu">{menuLinks}<a href="#servicos" onClick={() => setMobileOpen(false)}>Fotos dos cortes <ArrowRight size={15} /></a></div>}
      </header>

      {shopPickerOpen && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setShopPickerOpen(false); }}>
        <section className="shop-picker-modal" role="dialog" aria-modal="true" aria-labelledby="shop-picker-title">
          <div className="shop-picker-heading"><span className="settings-group-icon"><Store size={19} /></span><div><span className="eyebrow">ESCOLHA ONDE QUER CORTAR</span><h2 id="shop-picker-title">Escolher barbearia</h2></div><button className="icon-action" aria-label="Fechar" onClick={() => setShopPickerOpen(false)}><X size={18} /></button></div>
          {shops.isLoading ? <div className="empty-state">Carregando barbearias…</div> : shops.data?.length ? <div className="shop-picker-list">{shops.data.map(shop => <article className="shop-picker-item" key={shop.id}><span className="shop-picker-icon"><Scissors size={18} /></span><strong>{shop.name}</strong>{auth.user?.selectedBarbershopId === shop.id ? <span className="shop-selected-label"><Check size={15} /> Escolhida</span> : <button className="button button-outline small-button" disabled={selectShop.isPending} onClick={() => chooseShop(shop.id)}>{!auth.user ? "Entrar e escolher" : "Escolher"}</button>}</article>)}</div> : <div className="shop-picker-empty"><Store size={25} /><strong>Ainda não há barbearias cadastradas</strong><span>Um cabeleireiro pode entrar e criar a primeira.</span></div>}
          <p className="shop-picker-footnote">Depois de entrar como cliente, sua escolha fica salva na conta.</p>
        </section>
      </div>}

      <main>
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow"><span className="eyebrow-line" /> ATENDIMENTO COM HORA MARCADA</span>
            <h1>Corte bem feito.<br /><em>No seu horário.</em></h1>
            <p>Escolha o serviço, peça seu horário e deixe o resto com a gente. Sem correria, com atenção a cada detalhe.</p>
            <div className="hero-actions"><a href="#agendar" className="button button-primary">Marcar meu horário <ArrowRight size={17} /></a><a href="#servicos" className="hero-secondary">Conhecer os cortes <ArrowDown size={15} /></a></div>
            <div className="hero-proof"><span><Clock3 size={16} /> Horário combinado</span><i /><span><ShieldCheck size={16} /> Pedido confirmado pelo barbeiro</span></div>
          </div>
          <div className="hero-art" aria-label="Foto de corte degradê">
            <div className="hero-image-frame"><img src={services[0].image} alt="Corte degradê masculino com acabamento preciso" /><div className="image-shade" /></div>
            <div className="hero-image-caption"><span className="caption-number">01</span><span><strong>Detalhe em cada linha</strong><small>Seu corte, no seu tempo</small></span><Scissors size={18} /></div>
            <div className="hero-stamp"><span>NO<br />HORÁRIO</span><div className="stamp-dot" /></div>
          </div>
          <div className="hero-index">01 <span /> 04</div>
        </section>

        <section className="services-section" id="servicos">
          <div className="section-heading"><div><span className="eyebrow">MENU · SERVIÇOS</span><h2>Escolha seu <em>estilo.</em></h2></div><p>Veja os acabamentos e escolha o serviço que combina com você.</p></div>
          <div className="service-grid">{services.map((service, index) => <button key={service.value} className={`service-card ${form.service === service.value ? "service-selected" : ""}`} onClick={() => chooseService(service.value)}><span className="service-image"><img src={service.image} alt={`Exemplo de corte/serviço ${service.name}`} loading={index === 0 ? "eager" : "lazy"} /><span className="service-index">0{index + 1}</span><span className="service-tag">{service.tag}</span></span><span className="service-card-copy"><span><strong>{service.name}</strong><small>{service.short}</small></span><span className="service-arrow"><ArrowRight size={17} /></span></span></button>)}</div>
        </section>

        <section className="booking-section" id="agendar">
          <div className="booking-intro"><span className="eyebrow">02 · SEU PRÓXIMO HORÁRIO</span><h2>Vamos marcar<br /><em>seu corte?</em></h2><p>Escolha o serviço e indique o melhor dia e horário. Seu pedido fica aguardando a confirmação do cabeleireiro.</p><div className="booking-steps"><div><span>1</span><p><strong>Escolha o serviço</strong><small>Veja as fotos no menu</small></p></div><div><span>2</span><p><strong>Indique o horário</strong><small>Dia e horário preferidos</small></p></div><div><span>3</span><p><strong>Aguarde a confirmação</strong><small>Acompanhe em “Meus horários”</small></p></div></div></div>
          <form className="booking-form" onSubmit={submitBooking}>
            <div className="booking-form-title"><div className="form-icon"><CalendarDays size={19} /></div><div><span className="eyebrow">PEDIDO DE HORÁRIO</span><h3>Seu horário</h3></div></div>
            <div className="booking-selected-shop" id="escolher-barbearia"><Store size={16} /><span><small>SUA BARBEARIA</small><strong>{hasSelectedShop ? businessNameQuery.data ?? "Barbearia" : "Escolha uma barbearia"}</strong></span><button type="button" onClick={() => setShopPickerOpen(true)}>{hasSelectedShop ? "Trocar" : "Escolher"}</button></div>
            <fieldset className="service-picker"><legend>1. Qual serviço você quer?</legend><div className="service-picker-grid">{services.map(service => <button type="button" key={service.value} className={`service-choice ${form.service === service.value ? "selected" : ""}`} onClick={() => { setForm({ ...form, service: service.value }); setSent(false); }}><img src={service.image} alt="" loading="lazy" /><span>{service.name}</span>{form.service === service.value && <Check size={14} />}</button>)}</div></fieldset>
            <div className="form-grid"><label>Dia que prefere<input required type="date" min={today} value={form.appointmentDate} onChange={event => setForm({ ...form, appointmentDate: event.target.value })} /></label><label>Horário que prefere<input required type="time" value={form.appointmentTime} onChange={event => setForm({ ...form, appointmentTime: event.target.value })} /></label><label className="wide-field">Observação <span className="optional">opcional</span><input maxLength={500} value={form.note} onChange={event => setForm({ ...form, note: event.target.value })} placeholder="Alguma preferência?" /></label></div>
            <button type="submit" className="button button-primary booking-submit" disabled={request.isPending}>{request.isPending ? "Enviando pedido…" : sent ? <>Pedido enviado <Check size={16} /></> : <>Pedir este horário <ArrowRight size={17} /></>}</button>
            <p className="form-privacy"><ShieldCheck size={14} /> Usaremos o nome e o telefone do seu perfil de cliente.</p>
            {sent && <div className="success-message" role="status"><Check size={18} /><span><strong>Pedido enviado!</strong> O cabeleireiro vai confirmar seu horário. Você acompanha pelo menu de acesso.</span></div>}
            {!auth.user && <div className="login-hint">Entre como cliente para acompanhar seu pedido. <Link href="/entrar">Iniciar sessão</Link></div>}
          </form>
        </section>

        <section className="closing-banner"><div className="closing-mark"><Scissors size={21} /></div><div><span className="eyebrow">CUIDADO NO DETALHE. RESPEITO AO SEU TEMPO.</span><h2>Seu horário, <em>do seu jeito.</em></h2></div><a href="#agendar" className="button button-outline">Escolher horário <ArrowRight size={16} /></a></section>
      </main>

      <footer className="site-footer"><Link href="/" className="footer-brand"><Scissors size={17} /><span>{shopName}</span></Link><span>Atendimento organizado. Corte caprichado.</span><div><Link href="/configuracoes">Configurações</Link><Link href="/entrar">Entrar</Link></div><small>© {new Date().getFullYear()} {shopName} · Cortes com hora marcada</small></footer>
    </div>
  );
}
