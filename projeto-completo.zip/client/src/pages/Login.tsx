import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, Check, Scissors, ShieldCheck, UserRound, UserRoundCog } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { useAuth } from "../_core/hooks/useAuth";

type Profile = { firstName: string; lastName: string; birthDate: string; phone: string };
const emptyProfile: Profile = { firstName: "", lastName: "", birthDate: "", phone: "" };
const todayParts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
const todayValues = Object.fromEntries(todayParts.map(part => [part.type, part.value]));
const today = `${todayValues.year}-${todayValues.month}-${todayValues.day}`;

export default function Login() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const businessNameQuery = trpc.settings.businessName.useQuery(undefined, { enabled: Boolean(user) });
  const shopName = user ? businessNameQuery.data ?? "Barbearia" : "Gerencie sua barbearia";
  const mode = new URLSearchParams(window.location.search).get("tipo");
  const [profile, setProfile] = useState<Profile>(emptyProfile);
  const saveProfile = trpc.auth.saveCustomerProfile.useMutation({
    onSuccess: async () => {
      toast.success("Cadastro de cliente concluído.");
      await utils.auth.me.invalidate();
      if (sessionStorage.getItem("barber.pendingBooking")) setLocation("/");
    },
    onError: error => toast.error(error.message),
  });
  const selectBarbershop = trpc.shops.select.useMutation({
    onSuccess: async () => {
      sessionStorage.removeItem("barber.pendingShop");
      await Promise.all([utils.auth.me.invalidate(), utils.settings.businessName.invalidate()]);
      toast.success("Barbearia escolhida.");
      setLocation("/");
    },
    onError: error => {
      sessionStorage.removeItem("barber.pendingShop");
      toast.error(error.message);
    },
  });
  const logout = trpc.auth.logout.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); toast.success("Sessão encerrada. Agora entre com a conta autorizada."); },
    onError: error => toast.error(error.message),
  });
  const isBarber = user?.role === "barber" || user?.role === "admin";
  const isClientProfileComplete = Boolean(user?.firstName && user?.lastName && user?.birthDate && user?.phone);

  useEffect(() => {
    if (!user || !user.firstName || !user.lastName || !user.birthDate || !user.phone || selectBarbershop.isPending) return;
    const pendingId = Number(sessionStorage.getItem("barber.pendingShop"));
    if (Number.isSafeInteger(pendingId) && pendingId > 0) selectBarbershop.mutate({ barbershopId: pendingId });
  }, [user?.id, user?.firstName, user?.lastName, user?.birthDate, user?.phone]);

  const submitProfile = (event: FormEvent) => {
    event.preventDefault();
    saveProfile.mutate(profile);
  };

  return (
    <main className="auth-page">
      <Link href="/" className="back-link"><ArrowLeft size={17} /> Voltar à página inicial</Link>
      <section className="auth-card">
        <div className="brand-mark small"><Scissors size={20} /></div>
        <span className="eyebrow">{shopName.toUpperCase()} · ÁREA DE ACESSO</span>
        {!mode && <>
          <h1>Como você quer<br /><em>entrar?</em></h1>
          <p>Escolha a área certa para continuar.</p>
          {user && <div className="signed-in-note"><Check size={16} /> Sessão já iniciada nesta conta.</div>}
          <div className="role-options">
            <button className="role-option" disabled={loading} onClick={() => startLogin("client")}>
              <span className="role-icon"><UserRound size={20} /></span>
              <span><strong>Iniciar sessão como cliente</strong><small>Marcar e acompanhar seus horários</small></span>
              <ArrowRight size={17} />
            </button>
            <button className="role-option" disabled={loading} onClick={() => startLogin("barber")}>
              <span className="role-icon"><UserRoundCog size={20} /></span>
              <span><strong>Iniciar sessão como cabeleireiro</strong><small>Entrar na área de gestão da barbearia</small></span>
              <ArrowRight size={17} />
            </button>
            <button className="role-option admin-role-option" disabled={loading} onClick={() => startLogin("admin")}>
              <span className="role-icon"><ShieldCheck size={20} /></span>
              <span><strong>Entrar como administrador</strong><small>Acesso reservado à conta autorizada</small></span>
              <ArrowRight size={17} />
            </button>
          </div>
          <p className="auth-note">Qualquer cabeleireiro pode entrar e criar sua própria barbearia. A conta de administrador continua protegida separadamente.</p>
        </>}

        {mode === "cliente" && <>
          <h1>Área do<br /><em>cliente.</em></h1>
          {!user ? <>
            <p>Entre para concluir seu cadastro e pedir um horário.</p>
            <button className="button button-primary login-button" disabled={loading} onClick={() => startLogin("client")}><UserRound size={17} /> Entrar como cliente</button>
          </> : isClientProfileComplete ? <div className="signed-in-box">
            <ShieldCheck size={20} />
            <span>Bem-vindo, Cliente <strong>{user.firstName} {user.lastName}</strong></span>
            <Link href="/painel" className="button button-primary">Meus horários <ArrowRight size={16} /></Link>
            <Link href="/#agendar" className="secondary-link">Marcar outro horário</Link>
          </div> : <>
            <p>Crie seu perfil com somente estas informações:</p>
            <form className="profile-form" onSubmit={submitProfile}>
              <label>Nome<input autoComplete="given-name" required minLength={1} maxLength={80} value={profile.firstName} onChange={event => setProfile({ ...profile, firstName: event.target.value })} /></label>
              <label>Sobrenome<input autoComplete="family-name" required minLength={1} maxLength={80} value={profile.lastName} onChange={event => setProfile({ ...profile, lastName: event.target.value })} /></label>
              <label>Data de nascimento<input autoComplete="bday" type="date" required max={today} value={profile.birthDate} onChange={event => setProfile({ ...profile, birthDate: event.target.value })} /></label>
              <label>Telefone<input autoComplete="tel" type="tel" required minLength={8} maxLength={32} value={profile.phone} onChange={event => setProfile({ ...profile, phone: event.target.value })} placeholder="(00) 00000-0000" /></label>
              <button className="button button-primary" disabled={saveProfile.isPending}>{saveProfile.isPending ? "Salvando…" : <>Concluir cadastro <ArrowRight size={16} /></>}</button>
            </form>
          </>}
        </>}

        {mode === "cabeleireiro" && <>
          <h1>Área do<br /><em>cabeleireiro.</em></h1>
          {!user ? <>
            <p>Entre com sua conta para criar sua barbearia e gerir seus horários e clientes.</p>
            <button className="button button-primary login-button" disabled={loading} onClick={() => startLogin("barber")}><UserRoundCog size={17} /> Entrar como cabeleireiro</button>
          </> : isBarber ? <div className="signed-in-box">
            <ShieldCheck size={20} />
            <span>Bem-vindo, <strong>{user.firstName || user.name || "cabeleireiro"}</strong>.</span>
            <Link href="/painel" className="button button-primary">Criar barbearia / abrir painel <ArrowRight size={16} /></Link>
          </div> : <div className="pending-access">
            <ShieldCheck size={21} />
            <strong>Entre como cabeleireiro</strong>
            <span>Você pode criar a sua própria barbearia; não precisa de aprovação do administrador.</span>
            <button className="button button-outline" disabled={loading} onClick={() => startLogin("barber")}>Continuar como cabeleireiro</button>
          </div>}
        </>}

        {mode === "administrador" && <>
          <h1>Acesso do<br /><em>administrador.</em></h1>
          {!user ? <>
            <p>Entre com a conta autorizada pelo provedor. Este site não pede uma senha própria.</p>
            <button className="button button-primary login-button" disabled={loading} onClick={() => startLogin("admin")}><ShieldCheck size={17} /> Entrar como administrador</button>
          </> : user.role === "admin" ? <div className="signed-in-box">
            <ShieldCheck size={20} />
            <span>Conta administrativa autenticada.</span>
            <Link href="/painel" className="button button-primary">Abrir painel <ArrowRight size={16} /></Link>
          </div> : <div className="pending-access">
            <ShieldCheck size={21} />
            <strong>Esta conta não tem acesso de administrador</strong>
            <span>Encerre a sessão e entre pelo provedor com o e-mail autorizado.</span>
            <button className="button button-outline" disabled={logout.isPending} onClick={() => logout.mutate()}>{logout.isPending ? "Encerrando sessão…" : "Sair e trocar de conta"}</button>
          </div>}
        </>}

        {mode && <Link href="/entrar" className="secondary-link mode-back">Trocar tipo de acesso</Link>}
        <div className="auth-foot"><span><ShieldCheck size={14} /> Acesso seguro</span><span>{shopName}</span></div>
      </section>
    </main>
  );
}
