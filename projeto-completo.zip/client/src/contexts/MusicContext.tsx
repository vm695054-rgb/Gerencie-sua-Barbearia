import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { trpc } from "@/lib/trpc";

export const MUSIC_TRACKS = [
  { id: "pixabay-dark-beat", title: "Dark, Beat, Dark ambient music", artist: "vaitsez · Pixabay", src: "/manus-storage/vaitsez-dark-dark-beat-620108_93506743.mp3", sourceUrl: "https://pixabay.com/music/trap-dark-dark-beat-620108/", original: false },
  { id: "corte-em-dia", title: "Corte em Dia", artist: "Instrumental original", src: "/manus-storage/music-corte-em-dia_a9edc372.mp3", sourceUrl: undefined, original: true },
  { id: "fade-tranquilo", title: "Fade Tranquilo", artist: "Instrumental original", src: "/manus-storage/music-fade-tranquilo_273102b1.mp3", sourceUrl: undefined, original: true },
  { id: "navalha-de-ouro", title: "Navalha de Ouro", artist: "Instrumental original", src: "/manus-storage/music-navalha-de-ouro_f610fd05.mp3", sourceUrl: undefined, original: true },
] as const;
export type MusicTrackId = "none" | (typeof MUSIC_TRACKS)[number]["id"];

type MusicContextValue = { track: MusicTrackId; currentTrack: (typeof MUSIC_TRACKS)[number] | null; isPlaying: boolean; play: () => Promise<void>; pause: () => void };
const MusicContext = createContext<MusicContextValue | null>(null);

export function MusicProvider({ children }: { children: ReactNode }) {
  const { data: user } = trpc.auth.me.useQuery(undefined, { retry: false });
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const track = (MUSIC_TRACKS.some(item => item.id === user?.musicTrack) ? user?.musicTrack : "none") as MusicTrackId;
  const currentTrack = MUSIC_TRACKS.find(item => item.id === track) ?? null;

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!currentTrack) {
      audio.pause();
      audio.removeAttribute("src");
      audio.load();
      setIsPlaying(false);
      return;
    }
    audio.src = currentTrack.src;
    audio.load();
    if (isPlaying) void audio.play().catch(() => setIsPlaying(false));
  }, [currentTrack?.id]);

  const value = useMemo<MusicContextValue>(() => ({
    track,
    currentTrack,
    isPlaying,
    play: async () => {
      const audio = audioRef.current;
      if (!audio || !currentTrack) return;
      try { await audio.play(); setIsPlaying(true); } catch { setIsPlaying(false); }
    },
    pause: () => { audioRef.current?.pause(); setIsPlaying(false); },
  }), [track, currentTrack, isPlaying]);

  return <MusicContext.Provider value={value}>
    {children}
    <audio ref={audioRef} loop preload="none" onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} />
  </MusicContext.Provider>;
}

export function useMusic() {
  const context = useContext(MusicContext);
  if (!context) throw new Error("useMusic must be used within MusicProvider");
  return context;
}
