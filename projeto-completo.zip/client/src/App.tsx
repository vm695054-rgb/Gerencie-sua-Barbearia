import { useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { trpc } from "@/lib/trpc";
import { MusicProvider } from "@/contexts/MusicContext";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Settings from "./pages/Settings";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/entrar" component={Login} />
      <Route path="/painel" component={Dashboard} />
      <Route path="/configuracoes" component={Settings} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function SessionHeartbeat() {
  const { data: user } = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchInterval: 60_000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
  });
  useEffect(() => {
    localStorage.removeItem("manus-runtime-user-info");
    const root = document.documentElement;
    root.dataset.wallpaper = user?.backgroundStyle ?? "default";
    if (user?.backgroundImage) root.style.setProperty("--custom-wallpaper", `url("${user.backgroundImage}")`);
    else root.style.removeProperty("--custom-wallpaper");
  }, [user?.backgroundStyle, user?.backgroundImage]);
  return null;
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <MusicProvider>
            <Toaster />
            <SessionHeartbeat />
            <Router />
          </MusicProvider>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
